<?php

class us_migration_4_7 extends US_Migration_Translator {

	// Options
	public function translate_theme_options( &$options ) {

		return TRUE;
	}

}
